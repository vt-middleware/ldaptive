Connection conn = DefaultConnectionFactory.getConnection("ldap://directory.ldaptive.org");
